define([
    "episerver-telemetry-ui/tracker-factory"
], function (
    trackerFactory
) {
    return trackerFactory.getTracker("cms");
});

