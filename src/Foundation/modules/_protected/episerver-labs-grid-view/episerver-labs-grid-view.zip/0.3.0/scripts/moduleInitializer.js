define([
    "dojo",
    "dojo/_base/declare",

    "epi/_Module",
    "epi/dependency",
    "epi/routes",

     "epi/shell/store/JsonRest",

    "epi-cms/plugin-area/assets-pane",
    "./commands/showAssetsGrid",

     "./globalCommandsProvider"
], function (
    dojo,
    declare,

    _Module,
    dependency,
    routes,

    JsonRest,

    assetsPanePluginArea,
    ShowAssetsGrid,

    GlobalCommandsProvider
) {
    return declare([_Module], {
        initialize: function () {
            this.inherited(arguments);

            var registry = this.resolveDependency("epi.storeregistry");

            // Register Children store
            registry.add("childGrid.store",
                new JsonRest({
                    target: routes.getRestPath({ moduleArea: "episerver-labs-grid-view", storeName: "contentChildren" }),
                    idProperty: "contentLink"
                })
            );

            // Register ContentContainer store
            registry.add("contentContainer.store",
                new JsonRest({
                    target: routes.getRestPath({ moduleArea: "episerver-labs-grid-view", storeName: "contentContainer" }),
                    idProperty: "contentLink"
                })
            );

            // Register additional global command provider
            if (this._settings.childrenConvertCommandEnabled) {
                var commandsProvider = new GlobalCommandsProvider();

                var commandregistry = dependency.resolve("epi.globalcommandregistry");
                var area = "epi.cms.globalToolbar";
                commandregistry.registerProvider(area, commandsProvider);
            }
            assetsPanePluginArea.add(ShowAssetsGrid);
        }
    });
});
