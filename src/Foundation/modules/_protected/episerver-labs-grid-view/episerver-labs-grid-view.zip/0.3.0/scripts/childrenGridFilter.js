define([
    // dojo
    "dojo/_base/declare",
    "dojo/dom-class",

    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/CheckBox",
    "dijit/form/Select",

    // EPI
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/widget/SearchBox",

    // resources
    "dojo/text!./templates/childrenGridFilter.html",
    "xstyle/css!./styles.css"
], function (
    declare,
    domClass,

    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    CheckBox,
    Select,

    _ModelBindingMixin,
    SearchBox,

    template
) {
        return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin], {
            templateString: template,

            modelBindingMap: {
                includeDescendants: ["includeDescendants"],
                searchTerm: ["searchTerm"],
                allLanguages: ["allLanguages"],
                contentStatus: "contentStatus"
            },

            postCreate: function () {
                this.inherited(arguments);

                this.own(
                    this.includeDescendantsCheckbox.on("click", function (e) {
                        var checked = e.target.checked;
                        this.model.set("includeDescendants", checked);
                    }.bind(this)),
                    this.searchTermText.on("searchBoxChange", function (searchText) {
                        if (this.model.searchTerm === searchText) {
                            return;
                        }
                        this.model.set("searchTerm", searchText);
                    }.bind(this)),

                    this.allLanguagesCheckbox.on("click", function (e) {
                        var checked = e.target.checked;
                        this.model.set("allLanguages", checked);
                    }.bind(this))

                );

                this._initContentStatusFilter();
                this.own(this.contentStatusDropdown.on("change", function (value) {
                    if (this.model.contentStatus === value) {
                        return;
                    }
                    this.model.set("contentStatus", value);
                }.bind(this)));
            },

            _initContentStatusFilter: function () {
                this.contentStatusDropdown = new Select({
                    name: "select2",
                    options: [
                        { label: "All", value: null },
                        { label: "Draft", value: "CheckedOut", selected: true },
                        { label: "Published", value: "Published" },
                        { label: "Rejected", value: "Rejected" }
                    ]
                }, this.contentStatusDropdown);
                this.contentStatusDropdown.set("value", "");
            },

            _setIncludeDescendantsAttr: function (value) {
                this._set("includeDescendants", value);
                this.includeDescendantsCheckbox.set("value", value);
            },

            _setAllLanguagesAttr: function (value) {
                this._set("allLanguages", value);
                this.allLanguagesCheckbox.set("value", value);
            },

            _setSearchTermAttr: function (value) {
                this._set("searchTerm", value);
                this.searchTermText.set("value", value);
                this.searchTermText.toggleClearButton();
                if (!value) {
                    this.searchTermText._valueChanged();
                }
            },

            _setContentStatusAttr: function (value) {
                this._set("contentStatus", value);
                this.contentStatusDropdown.set("value", value);
            },

            _setShowDescendantsVisibleAttr: function (value) {
                domClass.toggle(this.includeDescendantsContainer, "dijitHidden", !value);
            },

            _setContentStatusVisibleAttr: function (value) {
                domClass.toggle(this.contentStatusContainer, "dijitHidden", !value);
            }
        });
    });
