﻿define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/topic",
    "epi/dependency",
    "epi-cms/contentediting/command/_ContentCommandBase"
],

function (
    declare,
    when,
    topic,
    dependency,
    _ContentCommandBase
) {

    return declare([_ContentCommandBase], {
        name: "moveLevelUp",
        label: null,
        tooltip: "Move to parent content", //TOO: recources

        settings: {
            "class": "move-up epi-chromeless epi-flat",
            iconClass: "epi-iconUp",
            showLabel: false
        },

        constructor: function () {
            var registry = dependency.resolve("epi.storeregistry");
            this.store = registry.get("epi.cms.contentdata");
        },

        _execute: function () {
            if (!this.model.contentData || !this.model.contentData.parentLink) {
                return;
            }
            when(this.store.get(this.model.contentData.parentLink)).then(function(contentData) {
                if (!contentData) {
                    return;
                }

                topic.publish("/epi/shell/context/request", { uri: contentData.uri }, { sender: null });
            }.bind(this));
        },

        _onModelChange: function () {
            this.inherited(arguments);

            var contentData = this.model.contentData;
            this.set("canExecute", contentData && contentData.parentLink);
        }
    });

});
